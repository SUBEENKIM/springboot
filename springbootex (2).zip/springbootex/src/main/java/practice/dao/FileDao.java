package practice.dao;

import java.util.Map;

import practice.domain.Upload;

public interface FileDao {
  // 작성
  public void insert(Upload upload);
  //public void insert(Map<String,Object> valueMap, Upload upload);
  public void update(Upload upload);
}
